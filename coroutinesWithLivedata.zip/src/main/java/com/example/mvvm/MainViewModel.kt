package com.example.mvvm

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mvvm.model.Response
import com.example.mvvm.model.ResponseObj
import com.example.mvvm.repository.MainRepository
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel : ViewModel() {

    var textView = "Welcome to my application"
    fun updateText(outPut: String) {
        textView = outPut
    }

    val _uiState: MutableLiveData<ResponseObj> = MutableLiveData<ResponseObj>()


    fun getInfo(url: String) {
        viewModelScope.launch {
            getData(url)
        }
    }


    suspend fun getData(url: String) {

          withContext(Dispatchers.IO) {
            val response = MainRepository.fetch(url)
            Log.d("getJSON...", response.toString())
            val gson = Gson()
            _uiState.postValue(gson.fromJson(response, ResponseObj::class.java))
        }
    }
}
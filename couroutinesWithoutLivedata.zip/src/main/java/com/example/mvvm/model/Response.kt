package com.example.mvvm.model

data class Response(var date: String? = null,
                    var millisecondsSinceEpoch : Int?    = null,
                    var time: String? = null)
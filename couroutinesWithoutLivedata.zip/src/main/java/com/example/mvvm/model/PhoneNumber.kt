package com.example.mvvm.model


data class PhoneNumber (
    val type: String,
    val number: String
)
package com.example.mvvm

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mvvm.model.Response
import com.example.mvvm.model.ResponseObj
import com.example.mvvm.repository.MainRepository
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel :ViewModel() {

    var textView = "Welcome to my application"
    fun updateText(outPut:String) {
        textView =outPut
    }

      val _uiState :MutableLiveData<ResponseObj> = MutableLiveData<ResponseObj>()

//
    fun getInfo(url:String){
           viewModelScope.launch {
               getData(url)
          }
    }


      suspend fun getData(url: String):ResponseObj {

           return  withContext(Dispatchers.IO) {
            val response=MainRepository.fetch(url)
                Log.d("getJSON...", response.toString())
            val gson = Gson()
               gson.fromJson(response, ResponseObj::class.java)

//                Log.d("res...",res.firstName)
//              _uiState.value=gson.fromJson(response, ResponseObj::class.java)

        }




//        return withContext(Dispatchers.IO) {
//             val obj = URL(url)
//             val con = obj.openConnection() as HttpURLConnection
//             con.requestMethod = "GET"
//             val responseCode = con.responseCode
//             println("Response Code :: $responseCode")
//               if (responseCode == HttpURLConnection.HTTP_OK) { // connection ok
//                 val `in` =
//                     BufferedReader(InputStreamReader(con.inputStream))
//                 var inputLine: String?
//                 val response = StringBuffer()
//                 while (`in`.readLine().also { inputLine = it } != null) {
//                     response.append(inputLine)
//                 }
//                 `in`.close()
//                   Log.d("mainAct...",response.toString())
//                  response.toString()
////                   response.toString()
//             } else {
//                 ""
//             }


     }

}